package test_for_github;

public class test01 {
	private void syso() {

	}
}
